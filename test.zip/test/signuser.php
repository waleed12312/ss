<?php
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$password1 = $_POST['password1'];
$password2 = $_POST['password2'];
$phone = $_POST['phone'];
$conn = new mysqli('localhost', 'root', '', 'sianeh');
if($fname == null){
    header("Location: sign up.html? error = اسم المستخدم مطلوب");
    exit();
}
else if ($lname == null ){
    header("Location: sign up.html? error = اسم العائلة مطلوب");
    exit();
}
else if ($email == null ){
    header("Location: sign up.html? error = اليميل مطلوبه");
    exit();
}
else if ($password1 == null ){
    header("Location: sign up.html? error = كلمت المرور مطلوبه");
    exit();
}
else if ($password2 != $password1 ){
    header("Location: sign up.html? error = يجب مطابقت كلمت المرور");
    exit();
}
else if ($password2 == null ){
    header("Location: sign up.html? error = كلمت الكيد المرور مطلوبه");
    exit();
}
else if ($phone == null ){
    header("Location: sign up.html? error = رقم الهاتف مطلوب  ");
    exit();
}


if($conn -> connect_error){
    die('connection failed :' .$conn->connect_error);
}else {
    $stmt=$conn->prepare("INSERT INTO signupu ( fname , lname , email ,password , phone) values(?,?,?,?,?)");
    $stmt -> bind_param("ssssi",$fname,$lname,$email,$password1,$phone);
    echo "login successfully";
$stmt -> execute();
    $stmt -> close();
    $conn ->close();

  
$conn = new mysqli('localhost', 'root', '', 'sianeh');
if($conn -> connect_error){
    die('connection failed :' .$conn->connect_error);
}else {
    $stmt=$conn->prepare("INSERT INTO login ( user_name ,  password) values(?,?)");
    $stmt -> bind_param("ss",$email,$password1);
    $stmt -> execute();
    echo "login successfully";
    $stmt -> close();
    $conn ->close();
    header("Location: home.php");
    exit();
}
}
?>