<?php
session_start();
include "db_conn.php";

if (isset($_POST['uname']) and isset($_POST['password']) ){

    function validate($data){
        $data=trim($data);
        $data=stripslashes($data);
        $data=htmlspecialchars($data);
        return $data ;
    }
}
else
{
    echo 'nooooooooooooooo';
}
$uname = validate($_POST['uname']);
$pass  = validate($_POST['password']);

if($uname == null){
    header("Location: index.php?error=اسم المستخدم مطلوبه");
    exit();
}
else if ($pass == null ){
    header("Location: index.php?error=كلمت المرور مطلوبه");
    exit();
}
$sql = " select * from login where user_name='$uname'and password='$pass'";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)===1){
  $row =mysqli_fetch_assoc($result);
  if($row['user_name']===$uname && $row['password']===$pass){
     echo "logged in";
     $_SESSION['user_name']=$row['user_name'];
     $_SESSION['name']=$row['name'];
     $_SESSION['id']=$row['id'];
     header("Location: home.php");
     exit();
}
else{
header("Location: index.php?error=اسم المستخدم أو كلمة المرور غير صحيحة");
exit();
}
}
else{
    header("Location: index.php?error=اسم المستخدم أو كلمة المرور غير صحيحة");
    exit();
}

