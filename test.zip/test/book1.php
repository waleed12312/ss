<?php
session_start();

$email = $_SESSION['user_name'];



$conn = new mysqli('localhost', 'root', '', 'sianeh');
if($conn -> connect_error){
    die('connection failed :' .$conn->connect_error);
}else {

    $sql =$conn->query( " select * from signupu where email='$email'");
    foreach($sql as $data)
{
  $name= $data["fname"];
  $phone= $data["phone"];
  $email= $data["email"];
}
if($stmt=$conn->prepare("INSERT INTO book ( name , email , phone ) values(?,?,?)")){
    $stmt -> bind_param("ssi",$name,$email,$phone);
    echo "login successfully";
    $stmt -> close();
    $conn ->close();
    header("Location: home.php");
    exit();}
    else
    echo "null";


}
?>