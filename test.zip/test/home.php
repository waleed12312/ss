<?php
session_start();
if(isset($_SESSION['id'])&& isset($_SESSION['user_name'])){
    ?>


<!DOCTYPE html>
<html lang="ar">
<head>
    <!--AIzaSyCUeDpm6lT2FuTvqC8JkFDFj9jKsYpMYNU-->
    <!--<script async
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCUeDpm6lT2FuTvqC8JkFDFj9jKsYpMYNU&callback=initMap">
</script>-->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sianeh </title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://kit.fontawesome.com/9f1d77ee43.js" crossorigin="anonymous"></script>
    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.checked {
  color: orange;
}
</style>

</head>
<body>
    
<!-- header section starts  -->

<header class="header" >
   <!-- <button> <a class ="logbt" href="logout.php"> تسجيل دخول </a></button>-->
   
   <a href="logout.php"> <buttn  class="btn" type ="submit" style="align-items:left ;">تسجيل الخوروج</buttn></a>
    <!--<a href="#" > <img src="image/logo hand.jpg" width="8%"></i> sianeh. </a>-->
    <img src="image/Screenshot.png"alt="user"  
    width="50" height="50" >
    <nav class="navbar">
        <a href="#home">الصفحة الرئيسية </a>
        <a href="#services">الخدمات</a>
        <a href="#about">من نحن</a>
       <!-- <a href="#doctors">doctors</a>-->
       <a href="compliment page.html" rel="nofollow" class="_97w5">  الشكاوي</a>
       <a href="book.php">احجز الان</a>
                
        <a href="#review">الاراء</a>
       
        
    </nav>

    <div id="menu-btn" class="fas fa-bars"></div>

</header>

<!-- header section ends -->

<!-- home section starts  -->

<section class="home" id="home">

    <div class="image">
        <img src ="image/gif img.webp" width="100%" >
    </div>

    <div class="content">
        <h3>sianeh</h3>
        <p>الموقع الاول في الاردن الذي يقدم ايدي عاملة في جميع المجالات وبأسعار رمزية </p>
        <a href="#services" class="btn"> ابحث عن طلبك <span class="fas fa-chevron-right"></span> </a>
    </div>

</section>

<!-- home section ends -->

<!-- icons section starts  -->



<!-- icons section ends -->

<!-- services section starts  -->

<section class="services" id="services">

    <h1 class="heading"> <!--our--> <span>خدماتنا</span> </h1>

    <div class="box-container">

        <div class="box">
           
            <img src="image/موا.jpg" alt="Avatar" style="width:85%">
            <h3>مواسرجي</h3>
            <p>هذا العامل متخصص بجميع اعمال صيانة المواسير وجميع اعمال السباكة</p>
            <a href="#book" class="btn"> احجز عامل  <span class="fas fa-chevron-right"></span> </a>
        </div>

        <div class="box">
            <img src="image/كه.jpg" alt="Avatar" style="width:85% height= 40%">
            <h3>كهربجي</h3>
            <p>هذا العامل متخصص بصيانة اعطال الكهرباء وتمديد الكهرباء </p>
            <a href="#book" class="btn"> احجز عامل  <span class="fas fa-chevron-right"></span> </a>
        </div>

        <div class="box">
            <img src="image/ده.png" alt="Avatar" style="width:70% ">
            <h3> دهين </h3>
            <p>هذا العامل مختصص بجميع اعمال الدهان والجبصين والديكور للمنزل </p>
            <a href="#book" class="btn"> احجز عامل  <span class="fas fa-chevron-right"></span> </a>
           
        </div>

        <div class="box">
            <img src="image/حدا.jpg" alt="Avatar" style="width:70%">
            <h3>حداد</h3>
            <p>هذا العامل متخصص بجميع اعمال الحدادة من صيانة وتركيب</p>
            <a href="#book" class="btn"> احجز عامل  <span class="fas fa-chevron-right"></span> </a>
        </div>

        <div class="box">
            <img src="image/نجا.jpg"  alt="Avatar" style="width:85% ">
            <h3>نجار</h3>
            <p>هذا العامل متخصص بجميع اعمال النجارة من صيانة وتركيب</p>
            <a href="#book" class="btn"> احجز عامل <span class="fas fa-chevron-right"></span> </a>
        </div>

        <div class="box">
            <img src="image/بل.jpg" alt="Avatar" style="width:70%">
            <h3>بليط</h3>
            <p>هذا العامل متخصص بجميع اعمال التبليط من صيانة او استلام ورشات</p>
            <a href="#book" class="btn"> احجز عامل <span class="fas fa-chevron-right"></span> </a>
        </div>

    </div>

</section>

<!-- services section ends -->

<!-- about section starts  -->

<section class="about" id="about">

    <h1 class="heading">  من <span>نحن</span></h1>

    <div class="row">

        <div class="image">
            <img src="image/about handy man.png" alt="">
        </div>

        <div class="content">
            <h3>نحن نخدمك وانت في منزلك </h3>
            <p>نحن موقع متخصص في تقديم افضل الايدي العاملة للمجتمع وبأرخص الاسعار وبخدمة مميزة جدا</p>
            <p>فقط قم بتسجيل الدخول واحجز العمل الذي تريده وسيصلك الى باب منزلك </p>
            <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
        </div>

    </div>

</section>

<!-- about section ends -->

<!-- doctors section starts  -->

<section class="doctors" id="doctors">

    <h1 class="heading"><span>العاملون</span> لدينا  </h1>

    <div class="box-container">

        <div class="box">
            <img src="image/wph.png" alt="Avatar" style="width:100%">
            <h3>john deo</h3>
            <span>expert workers</span><br>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star"></span>
            <span class="fa fa-star"></span>
            <div class="share">
                <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/wph.png" alt="Avatar" style="width:100%">
            <h3>john deo</h3>
            <span>expert workers</span><br>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star"></span>
            <span class="fa fa-star"></span>
            <div class="share">
                <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/wph.png" alt="Avatar" style="width:100%">
            <h3>john deo</h3>
            <span>expert workers</span><br>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star"></span>
            <span class="fa fa-star"></span>
            <div class="share">
                <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/wph.png" alt="Avatar" style="width:100%">
            <h3>john deo</h3>
            <span>expert workers</span><br>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star"></span>
            <span class="fa fa-star"></span>
            <div class="share">
                <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/wph.png" alt="Avatar" style="width:100%">
            <h3>john deo</h3>
            <span>expert workers</span><br>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star"></span>
            <span class="fa fa-star"></span>
            <div class="share">
                <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/wph.png" alt="Avatar" style="width:100%">
            <h3>john deo</h3>
            <span>expert workers</span><br>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star"></span>
            <span class="fa fa-star"></span>
            <div class="share">
                <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>
        </div>

    </div>

</section>

<!-- doctors section ends -->

<!-- booking section starts   -->

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

<!-- booking section ends -->

<!-- review section starts  -->

<section class="review" id="review">
    
    <h1 class="heading">  اراء  <span> المستخدمين  </span> </h1>

    <div class="box-container">

        <div class="box">
            <img src="image/pic-1.png" alt="">
            <h3>اسم المستخدم</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <p class="text">                                     رأي العميل                                     </p>
        </div>

        <div class="box">
            <img src="image/pic-2.png" alt="">
            <h3>اسم المستخدم</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <p class="text">رأي العميل                                                                       </p>
        </div>

        <div class="box">
            <img src="image/pic-3.png" alt="">
            <h3>اسم المستخدم</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <p class="text">رأي العميل 
                                                                                                            </p>
        </div>

    </div>

</section>
<section class="book" id="book">
    <h1 style="font-size: 1.6rem;  font-family: 'Poppins', sans-serif;">ادخل رأيك هنا</h1>
    <div>
        <form action="" method="post">
        <textarea name="comments" id="comments" placeholder=" Enter your comments here...
        
        ...and watch your comment box grow scrollbars!" style="color: black; border: 2cm;background-color: rgb(232, 241, 238); padding: auto;"> 
       </textarea>
       
        <input type="submit" value="تسليم" class ="btn">
        </form>
    </div>
</section>
<!-- review section ends -->
<section class="icons-container">

    <div class="icons">
        <i class="fas fa-users"></i>
        <h3>0</h3>
        <p>عامل حالي</p>
    </div>

    <div class="icons">
        <i class="fas fa-users"></i>
        <h3>0</h3>
        <p>عميل راض</p>
    </div>

    <!--<div class="icons">
        <i class="fa-duotone fa-hammer"></i>
        <h3>500+</h3>
        <p>bed facility</p>-->
    </div>

    <div class="icons">
        <i class="fas fa-users"></i>
        <h3>0</h3>
        <p>مستخدم</p>
    </div>

</section>

<!-- footer section starts  -->

<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>quick links</h3>
            <a href=" #home "> <i class="fas fa-chevron-right"></i> الصفحةالرئيسية </a>
            <a href="#services"> <i class="fas fa-chevron-right"></i> الخدمات </a>
            <a href="#about"> <i class="fas fa-chevron-right"></i> من نحن </a>
            <a href="#blogs"> <i class="fas fa-chevron-right"></i> الشكاوي </a>
            <a href="#book"> <i class="fas fa-chevron-right"></i> احجز الان </a>
            <a href="#"> <i class="fas fa-chevron-right"></i> الاراء </a>
            <a href="#"> <i class="fas fa-chevron-right"></i> blogs </a>
        </div>

        <div class="box">
            <h3>our services</h3>
            <a href="#"> <i class="fas fa-chevron-right"></i> مواسرجي </a>
            <a href="#"> <i class="fas fa-chevron-right"></i> كهربجي</a>
            <a href="#"> <i class="fas fa-chevron-right"></i>دهين </a>
            <a href="#"> <i class="fas fa-chevron-right"></i> حداد </a>
            <a href="#"> <i class="fas fa-chevron-right"></i> نجار </a>
            <a href="#"> <i class="fas fa-chevron-right"></i> بليط </a>
        </div>

        <div class="box">
            <h3>contact info</h3>
            <a href="#"> <i class="fas fa-phone"></i> +962 7 87066582 </a>
            <a href="#"> <i class="fas fa-phone"></i> +962 7 87066582 </a>
            <a href="#"> <i class="fas fa-envelope"></i> booddyy9999@gmail.com </a>
            <a href="#"> <i class="fas fa-envelope"></i> aboodj50@gmail.com </a>
            <a href="#"> <i class="fas fa-map-marker-alt"></i> amman, jordan - 400104 </a>
        </div>

        <div class="box">
            <h3>follow us</h3>
            <a href=" # "> <i class="fab fa-facebook-f"></i> facebook </a>
            <a href=" # "> <i class="fab fa-twitter"></i> twitter </a>
            <a href=" # "> <i class="fab fa-twitter"></i> twitter </a>
            <a href=" # "> <i class="fab fa-instagram"></i> instagram </a>
            <a href=" # "> <i class="fab fa-linkedin"></i> linkedin </a>
            <a href=" # "> <i class="fab fa-pinterest"></i> pinterest </a>
        </div>

    </div>

    <div class="credit"> created by <span>abd alfattah,waleed,mahmoud</span> | all rights reserved </div>

</section>

<!-- footer section ends -->


















<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>
<?php
}
else{
    header("Location: index.php");
    exit();
}
?>