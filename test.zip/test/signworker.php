<?php
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$password = $_POST['password'];
$phone = $_POST['phone'];
$location = $_POST['location'];
$colleg = $_POST['colleg'];
$age = $_POST['age'];
$now = $_POST['now'];

$conn = new mysqli('localhost', 'root', '', 'sianeh');
if($conn -> connect_error){
    die('connection failed :' .$conn->connect_error);
}else {
    $stmt=$conn->prepare("INSERT INTO signupw ( fname , lname , email ,password , phone ,colleg ,age , numofwork ,typeofjob) values(?,?,?,?,?,?,?,?,?)");
    $stmt -> bind_param("ssssisiis",$fname,$lname,$email,$password,$phone,$location,$colleg,$age,$now);
    $stmt -> execute();
    echo "login successfully";
    $stmt -> close();
    $conn ->close();
}
?>