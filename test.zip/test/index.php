<!DOCTYPE html>
<html>
<head>
<title>تسجيل الدخول</title>
<link rel="stylesheet" href="css/Login1.css">
<meta charset="UTF-8">
</head>
<body>
<form action="login.php" method="post">

<img src="image/Screenshot.png"alt="user"  
  width="80" height="80" >

<h2>تسجيل الدخول</h2>

<?php if(isset($_GET['error'])){?>

<p class="error"><?php echo $_GET['error'];?></p>
<?php }?>

<br>
<br>
<input type="text"  name="uname" placeholder="ايميل">
<input type="password"  name="password" placeholder="كلمت المرور">
<input type="submit" value="تسجيل الدخول">
<div >
   <p> نسية كلمة المرور ؟<a href="========" class="_97w4" target="">
      إعادة كلمة المرور</a></p>
      
       <p>  التسجيل في سيانة؟<a href="sign up.html" rel="nofollow" class="_97w5">
         التسجيل</a></p>
        
        
        </div>
</form>
</body>
</html>