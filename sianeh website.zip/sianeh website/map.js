function initMap(){
    var options ={
        center:{lat:38.3460  , lng:-0.4907},
        zoom:8
    }
    map = new google.maps.map(decumant.getElementById("map"),options)
const marker = new google.maps.marker({position:{lat:37.9922,lng:-101307},map:map}); 
}