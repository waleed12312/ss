<html>
<head>
<meta charset="UTF-8"><!--support the arabic language-->
<title>sign up</title>
<link rel="stylesheet" href="css/Signup1.css">
</head>
<body>
    <div class="signup-box">
<form>
    <h1>sign up</h1>
    <h4>It's free and takes a minute</h4>
    <label>First Name</label>
    <input type="text" placeholder="">
    <label>Last Name</label>
    <input type="text" placeholder="">
    <label>Email</label>
    <input type="email" placeholder="">
    <label>Password</label>
    <input type="password" placeholder="">
    <label>Confirm Password</label>
    <input type="password" placeholder="">
    <label>Phone Number</label>
    <input type="tel" placeholder="1234567890" 
    pattern="07[7-9]{1}[0-9]{3}[0-9]{4}" required>

    <input type="submit">
    <div class="div2" >
   <p> Already have an account <a href="Login.php" class="_97w4" target="">
        Login </a></p>

      <p> Sign up as worker<a href="sign up2.php" rel="nofollow" class="_97w5">
      Sign up </a></p> 
        
        </div>
</form>

</div>
</body>
</html>