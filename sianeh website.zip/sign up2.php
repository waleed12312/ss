<html>
<head>
<meta charset="UTF-8"><!--support the arabic language-->
<title>sign up</title>
<link rel="stylesheet" href="css/Signup2.css">

</head>
<body>
<div class="signup-box">
<form>
<div class="div1" >
    <h1>sign up</h1>
    <h4>It's free and takes a minute</h4>
    <label>First Name</label>
    <input type="text" placeholder=""><br>
    <label>Last Name</label>
    <input type="text" placeholder=""><br>
    <label>Email</label>
    <input type="email" placeholder=""><br>
    <label>Password</label>
    <input type="password" placeholder=""><br>
    <label>Confirm Password</label>
    <input type="password" placeholder=""><br>
    <label>Phone Number</label>
    <input type="tel" placeholder="1234567890" 
    pattern="07[7-9]{1}[0-9]{3}[0-9]{4}" required><br>
    <label>location\address</label>
    <input type="text" placeholder=""><br>
     <label>educational level</label>
    <input type="text" placeholder=""><br>
     <label >Age</label>
  <input type="number"   min="18" max="49"><br>
   <label >work completed</label>
  <input type="number"   min="0" max="100">
  
     </div>
        <div class="div2" >
    <input type="checkbox"  value="plumber">
  <label >plumber/مواسرجي</label><br>
  <input type="checkbox"  value="electrician">
  <label >electrician/كهربجي</label><br>
  <input type="checkbox"  value="fat">
  <label >fat/دهين</label><br>
  <input type="checkbox"  value="Smith">
  <label >Smith/حداد</label><br>
  <input type="checkbox" value="Carpenter">
  <label >Carpenter/نجار</label><br>
  <input type="checkbox"  value="tiles">
  <label >tiles/بليط</label>


  </div>
    <input type="submit">
    <div class="div3" >
   <p> Already have an account<a href="Login.php" class="_97w4" target=""> Login </a></p>
      </div>
</form>

</div>

</body>
</html>