<html>
<head>
<meta charset="UTF-8"><!--support the arabic language-->
<title>Login</title>
 <!-- custom css file link  -->
 <link rel="stylesheet" href="css/Login.css">
</head>
<body>

 <form>
 <img src="image/Screenshot.png"alt="user"  
  width="80" height="80" >

<h2>Login</h2>
<input type="text" placeholder="User Name">
<input type="password" placeholder="Enter Password">
<input type="button" value="Login">


<div >
   <p> Forgot Password ?<a href="========" class="_97w4" target="">
restert password</a></p>
      
       <p>  Sign up in sianeh ?<a href="sign up.php" rel="nofollow" class="_97w5">
            Sign up</a></p>
        
        
        </div>
</form>
</body>
</html>